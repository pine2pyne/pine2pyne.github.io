"""The fixed text around every module pine2pyne writes in the PyneComp layout.

The module opens with the ``@pyne`` magic docstring the PyneCore runtime looks for and
names the program that wrote it; it ends with the ``__main__`` footer that runs it.

Modules compiled by the closed PyneComp carry a docstring that names PyneComp instead. :func:`with_own_banner` puts
pine2pyne's docstring in its place, so a reference compares byte for byte with everything
after the banner: every comparison against PyneComp output goes through it, and a change
of this banner (or of pine2pyne's version) cannot break one.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

REPOSITORY_URL = 'https://github.com/pine2pyne/pine2pyne'

#: the docstring the closed PyneComp writes, any version (`PyneComp v6.0.79`, `v6.0.80`)
_PYNECOMP_BANNER = re.compile(
    r'\A"""\n(?P<magic>@pyne[^\n]*)\n\n'
    r'This code was compiled by PyneComp v[0-9.]+ — the Pine Script to Python compiler\.\n'
    r'Run with open-source PyneCore: https://pynecore\.org\n'
    r'Compile Pine Scripts online at PyneSys: https://pynesys\.io\n'
    r'"""\n')


def _version() -> str:
    from ... import __version__
    return __version__


@dataclass(frozen=True)
class PyneCompBanner:
    """Module docstring and ``__main__`` footer of a module in the PyneComp layout."""

    compiler: str = field(default_factory=lambda: f'pine2pyne {_version()}')
    magic: str = '@pyne edge'

    def header(self, magic: str | None = None) -> list[str]:
        return [
            '"""',
            magic or self.magic,
            '',
            f'This code was compiled by {self.compiler} — the Pine Script to PyneCore Python transpiler.',
            'Run with open-source PyneCore: https://pynecore.org',
            f'Source: {REPOSITORY_URL}',
            '"""',
        ]

    def footer(self) -> list[str]:
        return [
            'if __name__ == "__main__":',
            '    from pynecore.standalone import run',
            '    run(__file__)',
        ]


def with_own_banner(reference: str, banner: PyneCompBanner | None = None) -> str:
    """``reference``, a module PyneComp compiled, with pine2pyne's docstring in place of
    PyneComp's (the ``@pyne`` magic line kept); any other text is returned unchanged."""
    match = _PYNECOMP_BANNER.match(reference)
    if match is None:
        return reference
    header = (banner or PyneCompBanner()).header(match.group('magic'))
    return '\n'.join(header) + '\n' + reference[match.end():]
