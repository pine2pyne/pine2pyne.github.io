"""
Pine semantics: the checks TradingView's compiler makes that the grammar does not.

One read-only pass over the parsed Script, run by transpile() and by
`--validate` between the parser and the transformer. It keeps a Pine scope
model - the global scope, one scope per function (its parameters and body) and
one per if/for/while/switch body - and collects diagnostics at a Pine line and
1-based column: an identifier or call where one is at fault, else the
statement.

- A refusal is a program TradingView refuses whose transpile would give a
  silent wrong value, drop a statement or fail at a Python line; enforce()
  raises SemanticError for the first one and counts the rest.
- A warning is a program TradingView refuses that working files depend on:
  a same-scope redeclaration, a read before the
  declaration (from a function or block too) or in its own declaration.
  enforce() reports each once per (line, column, name, code) as a
  SemanticWarning, at its statement, when the script has no refusal; the
  output is unchanged. Also a warning, though TradingView compiles it: a
  `ta.*` call that runs on only some bars, whose history differs from the
  every-bar call (conditional_history_calls.py). Never hoisted.

The pass never rewrites the tree, so a script it accepts transpiles exactly as
before. An assignment to a history reference (`x[1] := v`) is refused by the
parser instead: the tree keeps no trace of it.

This scope model is a second one beside scope_renamer's. scope_decisions()
exposes how it resolves each read, and a corpus test compares that with the
renamer's resolution, so a drift between the two fails.
"""
import dataclasses
import itertools
import typing
import warnings
from typing import Dict, List, NamedTuple, Optional, Tuple

from .ast_nodes import (
    ArrayLiteral, Assignment, BinaryOp, EnumDecl, Expression, ExpressionStatement, ForInLoop, ForLoop, FuncDecl,
    FunctionCall, Identifier, IfExpression, IfStatement, IndexAccess, InputDecl, Literal, MemberAccess,
    MethodCall, NaLiteral, Reassignment, ReturnStatement, Script, Statement, SwitchExpression,
    SwitchStatement, TernaryOp, TupleDestructure, TypeDecl, UnaryOp, VarDecl, VaripDecl, WhileLoop,
)
from .ast_walk import walk
from .block_value_lowering import value_tails
from .bool_builtins import BOOL_BUILTINS
from .conditional_history_calls import conditional_history_calls
from .errors import SemanticError, SemanticWarning
from .library_collision import (
    FieldReadRule, HeadBinding, declared_type, global_binding_types, input_type, script_type_evidence,
)
from .namespace_members import NAMESPACE_MEMBERS
from .pine_builtins import PYNECORE_LIB_MODULES, SERIES_VARIABLES, input_positional_param_names
from .symbol_table import SymbolTable
from .udt_field_defaults import constant_heads, default_message, invalid_defaults, positioned_part

REFUSE, WARN = 'refuse', 'warn'
# Before Pine v3 a declaration may read its own name (v2 `x = nz(x[1]) + 1`)
LAST_SELF_REFERENCE_VERSION = 2
DISCARD = '_'
# `_` discards a value: MEASURED on TradingView 2026-11-14, reading it fails in Pine v4 too (`_ = close * 2`,
# `plot(_)`: `Undeclared identifier '<_1>'`), as in v5 and v6
DISCARD_FROM_VERSION = 4
# Pine v6 removed the history of a field of a user-defined type, `t.x[1]` (migration guide to v6, "History of
# UDT fields"); v5 accepts it
FIELD_HISTORY_REFUSED_FROM_VERSION = 6
# TradingView refuses a history read of a loop variable: MEASURED 2026-10-06 for a Pine v6 `for i = a to b`
# counter (VN301! 5m): `Error at 5:31: Variable "i" doesn't have history values (CE10078)`, 5:31 being the counter
# in `nz(i[1], -1)`; MEASURED 2026-11-13 (BINANCE:BTCUSDT 1D) for Pine v4 (`Variable 'i' doesn't have history
# values.`) and v5, and for both variables of a v5 `for [i, v] in arr` and the variable of `for v in arr`. Pine
# v1-v3 are not measured
LOOP_COUNTER_HISTORY_REFUSED_FROM_VERSION = 4
# MEASURED on TradingView 2026-11-13 (Pine v5): a tuple declaration whose right side has another number of values
# is a syntax error, a function's tuple or a `request.security` tuple alike: `[a, b] = f()` with `f()` =>
# `[close, open, high]` gives `Syntax error: The quantities of tuple elements on each side of the assignment
# operator do not match. The right side has 3 but the left side has 2.`, and `[a, b, c] = f()` with a pair gives
# `... The right side has 2 but the left side has 3.`
# a `switch` is a value only as the whole right side of `=`, `:=` or a compound assignment (`s += switch ...`), never as
# an operand of an operator (`1 + switch k`, `c and switch k`): TradingView refuses those with CE10150
SWITCH_OPERAND_MESSAGE = '"switch" cannot be used as a variable or function name. (CE10150)'
# Pine v4-v6 refuse an untyped declaration whose value is the na literal, `x = na`
# and `var x = na` alike: the variable has no type to take from it
UNTYPED_NA_MESSAGE = 'Value with NA type cannot be assigned to a variable that was defined without type keyword'
# Pine v5 and v6 refuse a field or a method read straight off a history index,
# `t[1].v` or `a[1].size()`; `(t[1]).v` compiles. Pine v4 has neither (not measured)
MEMBER_OF_HISTORY_MESSAGE = "User variable identifiers should not contain '.'"
MEMBER_OF_HISTORY_REFUSED_FROM_VERSION = 5
NA_BLOCK_OF_A_BOOL_MESSAGE = ('Return type of one of the "if" or "switch" blocks is not compatible with return '
                              'type of other block(s) (series bool; simple na)')
UNTYPED_NA_REFUSED_FROM_VERSION = 4
TUPLE_WIDTH_MESSAGE = ('Syntax error: The quantities of tuple elements on each side of the assignment operator do '
                       'not match. The right side has {right} but the left side has {left}.')
SECURITY_FUNCTIONS = frozenset({'request.security', 'security'})
# MEASURED on TradingView 2026-11-13 (Pine v5): an int counter cannot take a fractional step, `for i = 0 to 3 by
# 0.5` gives `The increment/decrement value type ('literal float') of the 'for' loop is not compatible with counter
# 'i' type ('series int')` (a `const float` variable as the step is refused too, its message not read)
# MEASURED on TradingView 2026-11-13 (Pine v5): `b = input.source(a, "B")` with `a = input.source(close, "A")` does
# not compile; the default of input.source is one of the chart's own sources. MEASURED on TradingView 2026-11-14
# (Pine v4): `input(a, "B", type=input.source)` with another input, a user variable, `sma(close, 3)` or `vwap` does
# not compile either ("Arguments of input function must be of constant type, or 'source' builtin variables");
# `ohlc4` does
INPUT_SOURCE_CHECKED_FROM_VERSION = 4
INPUT_SOURCE_V4_MESSAGE = "Syntax error: Arguments of input function must be of constant type, or 'source' builtin variables."
INPUT_SOURCE_VALUES = ('open', 'high', 'low', 'close', 'hl2', 'hlc3', 'ohlc4', 'hlcc4', 'volume')
INPUT_SOURCE_MESSAGE = ("Invalid value for the 'defval' parameter of the 'input.source' function. Possible values: "
                        "[" + ', '.join(INPUT_SOURCE_VALUES) + "].")
FOR_STEP_TYPE_MESSAGE = ("The increment/decrement value type ('literal float') of the 'for' loop is not "
                         "compatible with counter '{}' type ('series int')")
# Pine v6 has no na bool (Pine v6 migration guide; PyneCore documentation): na() of a bool, nz() or fixnan() of
# one, `bool b = na` and `b := na` are refused. Only a value known to be a bool is refused: a literal, a comparison,
# `not`, `and`/`or`, a bool builtin or input, a typed bool parameter, a name declared from one of these (or typed
# bool), its history, a ternary of such arms, a user function whose value is one; a field of a user type is not
# (PyneComp v6.1.0 compiles `na(t.flag)` too)
BOOL_NEVER_NA_FROM_VERSION = 6
BOOL_OPERATORS = frozenset({'==', '!=', '<', '>', '<=', '>=', 'and', 'or'})
BOOL_NEVER_NA_MESSAGE = 'a bool is never na in Pine v6'
# Pine v6's namespaces: the heads of the dotted names of the TradingView v6
# reference (pinescript-docs-scraper pine_reference_types.json, 2026-03-12)
PINE_NAMESPACES = frozenset({
    'adjustment', 'alert', 'array', 'backadjustment', 'barmerge', 'barstate', 'box', 'chart', 'color',
    'currency', 'dayofweek', 'display', 'dividends', 'earnings', 'extend', 'font', 'footprint', 'format',
    'hline', 'input', 'label', 'line', 'linefill', 'location', 'log', 'map', 'math', 'matrix', 'order',
    'plot', 'polyline', 'position', 'request', 'runtime', 'scale', 'session', 'settlement_as_close',
    'shape', 'size', 'splits', 'str', 'strategy', 'syminfo', 'ta', 'table', 'text', 'ticker',
    'timeframe', 'volume_row', 'xloc', 'yloc',
})
# Pine v6's bare built-in variables (the same reference)
PINE_BUILTIN_VARIABLES = frozenset({
    'ask', 'bar_index', 'bid', 'close', 'dayofmonth', 'dayofweek', 'false', 'high', 'hl2', 'hlc3',
    'hlcc4', 'hour', 'last_bar_index', 'last_bar_time', 'low', 'minute', 'month', 'na', 'ohlc4', 'open',
    'second', 'time', 'time_close', 'time_tradingday', 'timenow', 'true', 'volume', 'weekofyear', 'year',
})
# The bare built-in variables of Pine v4 and before that v5 moved into namespaces
LEGACY_BUILTIN_VARIABLES = frozenset({
    'accdist', 'iii', 'interval', 'isdaily', 'isdwm', 'isintraday', 'ismonthly', 'isweekly', 'n', 'nii',
    'nvi', 'obv', 'period', 'pvi', 'pvt', 'ticker', 'tickerid', 'tr', 'vwap', 'wad', 'wvad',
})
LAST_LEGACY_VERSION = 4
# Pine v3 and before: colours, styles, locations, shapes, sizes and days as bare constants
PRE_V4_CONSTANTS = frozenset({
    'aqua', 'black', 'blue', 'fuchsia', 'gray', 'green', 'lime', 'maroon', 'navy', 'olive', 'orange',
    'purple', 'red', 'silver', 'teal', 'white', 'yellow', 'line', 'stepline', 'histogram', 'cross', 'area',
    'columns', 'circles', 'solid', 'dotted', 'dashed', 'abovebar', 'belowbar', 'top', 'bottom', 'absolute',
    'xcross', 'circle', 'triangleup', 'triangledown', 'flag', 'arrowup', 'arrowdown', 'square', 'diamond',
    'labelup', 'labeldown', 'auto', 'tiny', 'small', 'normal', 'large', 'huge', 'monday', 'tuesday',
    'wednesday', 'thursday', 'friday', 'saturday', 'sunday',
})
LAST_PRE_V4_VERSION = 3
# An enum cannot take a namespace's name (`str` and `input` included, docs 7144);
# a UDT can (docs 6876: "UDT names shadow the language's namespaces")
RESERVED_ENUM_NAMES = PINE_NAMESPACES
# Names a bare read may mean without a declaration in the script: never out of scope
BUILTIN_NAMES = (PINE_BUILTIN_VARIABLES | PINE_NAMESPACES | frozenset(SymbolTable().builtin_symbols)
                 | SERIES_VARIABLES | PYNECORE_LIB_MODULES | frozenset(NAMESPACE_MEMBERS))
PARAMETER, LOOP_VARIABLE, INPUT, VARIABLE = 'parameter', 'loop variable', 'input', 'variable'
LOOP_COUNTER = 'loop counter'  # a variable of `for i = a to b` or `for ... in`: a loop variable that has no history
STATEMENT_TYPES = typing.get_args(Statement)
SCOPE_KIND_TEXT = {'if': 'an if block', 'for': 'a for loop', 'while': 'a while loop',
                   'switch': 'a switch', 'function': 'a function'}
UNDECLARED_MESSAGE = ("'{}' is declared only inside a block or function that has ended here; "
                      "TradingView reports it as undeclared")


class Diagnostic(NamedTuple):
    severity: str
    code: str
    line: int
    column: int
    name: str
    message: str


class ReadDecision(NamedTuple):
    """How the pass resolved one read: `binding` is (scope number, name), or
    None when no declaration in the script is visible; `shadows` says whether
    that binding hides one of the same name in an enclosing scope (a global
    counts wherever it is declared, as scope_renamer binds every global first);
    `later_global` marks an unresolved read of a global declared further down."""
    binding: Optional[Tuple[int, str]]
    shadows: bool
    later_global: bool


@dataclasses.dataclass
class _Scope:
    number: int
    kind: str
    names: Dict[str, str] = dataclasses.field(default_factory=dict)  # name -> how it was declared
    types: Dict[str, Optional[str]] = dataclasses.field(default_factory=dict)  # name -> its declared Pine type
    shadowing: set = dataclasses.field(default_factory=set)  # names declared here that hide an outer one
    bools: set = dataclasses.field(default_factory=set)  # names declared here that are known to hold a bool
    declared_ahead: frozenset = frozenset()  # names the scope's own statements declare, walked or not
    ended: set = dataclasses.field(default_factory=set)  # names bound in blocks nested here that have ended


def check_script(script: Script) -> List[Diagnostic]:
    """Every diagnostic for `script`, in source order."""
    return _SemanticCheck(script).run()


def enforce(script: Script) -> None:
    """Raise SemanticError for the first refusal, naming how many more there
    are; a script with no refusal gets one SemanticWarning per (line, column,
    name, code). A refused script is not warned about: the refusal is its
    verdict, also under `-W error`."""
    diagnostics = check_script(script)
    refusals = [diagnostic for diagnostic in diagnostics if diagnostic.severity == REFUSE]
    if refusals:
        first = refusals[0]
        raise SemanticError(first.code, first.message, first.line, first.column, len(refusals) - 1)
    warned = {(diagnostic.line, diagnostic.column, diagnostic.name, diagnostic.code): diagnostic
              for diagnostic in diagnostics if diagnostic.severity == WARN}
    for diagnostic in warned.values():
        warnings.warn(SemanticWarning(diagnostic.code, diagnostic.message, diagnostic.line, diagnostic.column),
                      stacklevel=3)


def scope_decisions(script: Script) -> Dict[Tuple[int, int, str], ReadDecision]:
    """(line, column, name) of every positioned bare-name read -> how the pass resolved it."""
    check = _SemanticCheck(script)
    check.run()
    return check.decisions


def _declared_names(node) -> List[str]:
    if isinstance(node, (VarDecl, VaripDecl, InputDecl)):
        return [node.name]
    if isinstance(node, Assignment):
        return list(node.target.names) if isinstance(node.target, TupleDestructure) else [node.target]
    return []


def _literal_of(node, literal_type: str) -> bool:
    return isinstance(node, Literal) and node.literal_type == literal_type


def _pine_version(script: Script) -> int:
    version = script.version.version if script.version else ''
    return int(version) if version.isdigit() else 1  # no annotation: Pine v1


class _SemanticCheck:
    def __init__(self, script: Script):
        self.script = script
        self.version = _pine_version(script)
        self.constant_heads = constant_heads(script)
        self.builtin_names = BUILTIN_NAMES | (LEGACY_BUILTIN_VARIABLES if self.version <= LAST_LEGACY_VERSION
                                              else frozenset()) \
            | (PRE_V4_CONSTANTS if self.version <= LAST_PRE_V4_VERSION else frozenset())
        self.top_items = sorted(list(script.declarations) + list(script.body), key=lambda item: item.line)
        self.diagnostics: List[Diagnostic] = []
        self.decisions: Dict[Tuple[int, int, str], ReadDecision] = {}
        self.line, self.column = 0, 0
        self.declaring: frozenset = frozenset()  # the names the statement being walked declares
        self.scope_numbers = itertools.count()
        self.global_names = {name for item in self.top_items for name in _declared_names(item)}
        self.field_read_rule = FieldReadRule(script)
        self.global_types = global_binding_types(script)
        self.type_evidence = script_type_evidence(script)
        every_node = list(walk(self.top_items))
        self.local_only = _names_declared_in(every_node) - self.global_names
        self.function_names = {node.name for node in every_node if isinstance(node, FuncDecl)}
        self.type_names = {node.name for node in every_node if isinstance(node, (TypeDecl, EnumDecl))}
        declared_count: Dict[str, int] = {}
        for item in self.top_items:
            if isinstance(item, FuncDecl) and not item.is_method:
                declared_count[item.name] = declared_count.get(item.name, 0) + 1
        self.overloaded = {name for name, count in declared_count.items() if count > 1}
        self.single_functions = {item.name: item for item in self.top_items if isinstance(item, FuncDecl)
                                 and not item.is_method and item.name not in self.overloaded}
        self.bool_functions = self.functions_of_bool_value()

    # ------------------------------------------------------------ reporting

    def report(self, severity: str, code: str, name: str, message: str, node=None) -> None:
        """A diagnostic at `node`'s own position when it has one, else the statement's."""
        line, column = (node.line, node.column) if getattr(node, 'line', 0) else (self.line, self.column)
        self.diagnostics.append(Diagnostic(severity, code, line, column, name, message))

    def at(self, node) -> None:
        if getattr(node, 'line', 0):
            self.line, self.column = node.line, node.column

    def at_expression(self, node) -> None:
        """An else-if condition or a switch case comes after a block that moved the
        position: take its own, from its first positioned part."""
        self.at(next((part for part in walk(node) if getattr(part, 'line', 0)), None))

    # ------------------------------------------------------------ scopes

    def new_scope(self, kind: str, statements=()) -> _Scope:
        declared = [name for statement in statements for name in _declared_names(statement)] \
            if isinstance(statements, list) else []
        return _Scope(next(self.scope_numbers), kind, declared_ahead=frozenset(declared))

    @staticmethod
    def declared_later(stack: List[_Scope], name: str) -> bool:
        """`name` is declared further down a scope that is still open (it is not bound yet)."""
        return any(name in scope.declared_ahead for scope in stack)

    def out_of_scope(self, stack: List[_Scope], name: str) -> bool:
        """An unbound `name` that only a scope which has ended declared so far: bound in
        an ended if/for/while/switch block of the reader's own scopes (the emitted
        Python would read that block's stale value; a name the statement itself
        declares is a self-reference instead), or local to other scopes and not
        declared later in an open one."""
        return ((name not in self.declaring and any(name in scope.ended for scope in self.own_scopes(stack)))
                or (name in self.local_only and not self.declared_later(stack, name)))

    @staticmethod
    def own_scopes(stack: List[_Scope]) -> List[_Scope]:
        """The open scopes a read sees as its own: from the innermost function
        scope in (a function reading a global is its own case), else all."""
        functions = [index for index, scope in enumerate(stack) if scope.kind == 'function']
        return stack[functions[-1]:] if functions else stack

    def declare(self, stack: List[_Scope], name: str, how: str, type_name: Optional[str] = None) -> None:
        if name == DISCARD:
            return
        scope = stack[-1]
        earlier = scope.names.get(name)
        if earlier is None:
            outer = any(name in enclosing.names for enclosing in stack[:-1])
            if outer or (len(stack) > 1 and name in self.global_names):
                scope.shadowing.add(name)
        elif INPUT in (earlier, how):  # an input is declared only at global scope (parser.py top-level loop)
            self.report(REFUSE, 'duplicate-input', name, f"'{name}' is already declared in this scope "
                        f'(an input and another declaration cannot share a name)')
        elif earlier not in (LOOP_VARIABLE, LOOP_COUNTER):
            # MEASURED on TradingView 2026-11-14 (v6): `x = 1.0` then `x = 2.0`, and a parameter declared again in
            # the function's body, fail to compile: `"x" is already defined`
            self.report(REFUSE, 'redeclared', name, f'"{name}" is already defined')
        scope.names.setdefault(name, how)
        scope.types.setdefault(name, type_name)  # the first declaration's, as scope_renamer binds it

    @staticmethod
    def depth_of(stack: List[_Scope], name: str) -> Optional[int]:
        for depth in range(len(stack) - 1, -1, -1):
            if name in stack[depth].names:
                return depth
        return None

    def read(self, stack: List[_Scope], identifier: Identifier) -> None:
        name = identifier.name
        depth = self.depth_of(stack, name)
        if identifier.line:
            binding = (stack[depth].number, name) if depth is not None else None
            shadows = depth is not None and name in stack[depth].shadowing
            later_global = depth is None and name in self.global_names
            self.decisions[identifier.line, identifier.column, name] = ReadDecision(binding, shadows, later_global)
        if name == DISCARD:
            if self.version >= DISCARD_FROM_VERSION:
                self.report(REFUSE, 'discard-read', name, "'_' discards a value and cannot be read", identifier)
            return
        if depth is not None or name in self.builtin_names or name in self.function_names or name in self.type_names:
            return
        if self.out_of_scope(stack, name):
            self.report(REFUSE, 'out-of-scope', name, UNDECLARED_MESSAGE.format(name), identifier)
        elif name in self.global_names or self.declared_later(stack, name):
            self.read_before_declaration(name)

    def read_before_declaration(self, name: str) -> None:
        """A read above the name's declaration in a scope that is still open, from
        any inner scope, or in its own declaration. MEASURED on TradingView
        2026-11-14 (v6): a function reading a global declared below it, and a
        global read above its declaration, fail to compile: `Undeclared
        identifier "g"`."""
        if name not in self.declaring:
            self.report(REFUSE, 'used-before-declaration', name, f'Undeclared identifier "{name}"')
        elif self.version > LAST_SELF_REFERENCE_VERSION:
            # MEASURED on TradingView 2026-11-14 (v4, v6): `x = nz(x[1]) + 1` gives `Undeclared identifier "x"`
            self.report(REFUSE, 'self-reference', name, f'Undeclared identifier "{name}"')

    # ------------------------------------------------------------ statements

    def run(self) -> List[Diagnostic]:
        self.recursion()
        stack = [self.new_scope('global')]
        for item in self.top_items:
            self.statement(item, stack)
        self.conditional_history_calls()
        return sorted(self.diagnostics, key=lambda diagnostic: (diagnostic.line, diagnostic.column))

    def conditional_history_calls(self) -> None:
        """A `ta.*` call that runs on only some bars keeps a history that differs from the
        every-bar call. A warning only: the call stays where the script has it."""
        for call in conditional_history_calls(self.script):
            self.report(WARN, 'conditional-history-call', call.func,
                        f"'{call.func}' is called only when its condition holds: its series history "
                        f'differs from an unconditional call (the output keeps the call where it is, as TradingView '
                        f'does; TradingView advises calling it on every bar, in the global scope)', call)

    def block(self, statements, stack: List[_Scope], kind: str, names=(), how=LOOP_VARIABLE,
              types: Optional[Dict[str, Optional[str]]] = None) -> None:
        inner = stack + [self.new_scope(kind, statements if statements is not None else ())]
        for name in names:
            self.declare(inner, name, how, (types or {}).get(name))
            if (types or {}).get(name) == 'bool':
                inner[-1].bools.add(name)
        if isinstance(statements, list):
            for statement in statements:
                self.statement(statement, inner)
        elif statements is not None:
            self.expression(statements, inner)
        if kind != 'function':  # a Python def keeps its locals; an if/for block leaks them
            stack[-1].ended.update(inner[-1].names, inner[-1].ended)

    def member_of_history(self, node, member: str) -> None:
        """Refuse `x[n].member` (a field or a method) written without parentheses."""
        if (self.version >= MEMBER_OF_HISTORY_REFUSED_FROM_VERSION and isinstance(node.object, IndexAccess)
                and not node.object.parenthesized):
            self.report(REFUSE, 'member-of-history', member, MEMBER_OF_HISTORY_MESSAGE, node.object)

    def statement(self, node, stack: List[_Scope]) -> None:
        self.at(node)
        if isinstance(node, FuncDecl):
            self.function(node, stack)
        elif isinstance(node, (VarDecl, VaripDecl, Assignment)):
            enclosing = self.declaring
            self.declaring = enclosing | frozenset(_declared_names(node))
            self.expression(node.value, stack)
            self.declaring = enclosing
            self.at(node)  # a block in the value moved the position
            if isinstance(getattr(node, 'target', None), TupleDestructure):
                right = self.tuple_width(node.value)
                if right is not None and right != len(node.target.names):
                    self.report(REFUSE, 'tuple-width', ', '.join(node.target.names),
                                TUPLE_WIDTH_MESSAGE.format(right=right, left=len(node.target.names)))
            for name in _declared_names(node):
                first = name not in stack[-1].names
                type_name = declared_type(node, self.type_evidence._replace(
                    variable_type=lambda variable: self.variable_type(variable, stack)))
                self.declare(stack, name, VARIABLE, type_name)
                if first and not isinstance(getattr(node, 'target', None), TupleDestructure) and (
                        type_name == 'bool' or (type_name is None and self.is_bool(node.value, stack))):
                    stack[-1].bools.add(name)
            self.bool_declared_na(node)
            if (self.version >= UNTYPED_NA_REFUSED_FROM_VERSION and node.type_hint is None
                    and _is_na(node.value)
                    and not isinstance(getattr(node, 'target', None), TupleDestructure)):
                self.report(REFUSE, 'untyped-na', _declared_names(node)[0], UNTYPED_NA_MESSAGE)
        elif isinstance(node, InputDecl):
            self.expression([node.args, list(node.kwargs.values())], stack)
            self.input_arguments(node, stack)
            self.declare(stack, node.name, INPUT, declared_type(node))
            if _is_a_bool_input(node):
                stack[-1].bools.add(node.name)
        elif isinstance(node, EnumDecl) and node.name in RESERVED_ENUM_NAMES:
            self.report(REFUSE, 'named-like-namespace', node.name,
                        f"an enum cannot be named '{node.name}', the name of a built-in namespace")
        elif isinstance(node, TypeDecl):
            for field_name, default in invalid_defaults(node, self.constant_heads):
                self.report(REFUSE, 'udt-field-default', field_name, default_message(node, field_name),
                            positioned_part(default))
        elif isinstance(node, Reassignment):
            self.expression(node.value, stack)
            self.at(node)  # a block in the value moved the position
            self.reassignment(node.target, stack)
            self.bool_reassigned_na(node, stack)
        elif isinstance(node, (IfStatement, ForLoop, ForInLoop, WhileLoop)):
            self.control_flow(node, stack)
        elif isinstance(node, SwitchStatement):
            self.switch(node, stack)
        elif isinstance(node, (ExpressionStatement, ReturnStatement)):
            self.expression(node.expr, stack)
        elif isinstance(node, Expression):
            self.expression(node, stack)

    def input_arguments(self, node: InputDecl, stack: List[_Scope]) -> None:
        """An input's arguments must be const, so they cannot read another input (manual,
        Inputs: "results from other input*() calls"); `active` takes an input bool, and
        input.source's `defval` a series float."""
        parameters = ['defval', 'title'] + input_positional_param_names(node.func, node.args)
        # a row that does not name `active` ends at `display`: a positional argument after it is `active`
        positional = (parameters[:parameters.index('display') + 1]
                      if 'display' in parameters and 'active' not in parameters else parameters)
        arguments = list(zip(positional, node.args)) + list(node.kwargs.items())
        if node.func == 'input.source' and self.version >= INPUT_SOURCE_CHECKED_FROM_VERSION:
            defval = dict(arguments).get('defval')
            if defval is not None and not (isinstance(defval, Identifier) and defval.name in INPUT_SOURCE_VALUES):
                self.report(REFUSE, 'input-source-defval', node.name,
                            INPUT_SOURCE_V4_MESSAGE if self.version == 4 else INPUT_SOURCE_MESSAGE, _positioned(defval))
        for parameter, argument in arguments:
            if parameter == 'active' or (parameter == 'defval' and node.func == 'input.source'):
                continue
            for read in walk(argument):
                if isinstance(read, Identifier) and self.depth_of(stack, read.name) == 0 \
                        and stack[0].names[read.name] == INPUT:
                    self.report(REFUSE, 'input-argument-reads-input', read.name,
                                f"the '{parameter}' argument of input '{node.name}' reads the input "
                                f"'{read.name}'; TradingView requires a const argument there", read)

    def control_flow(self, node, stack: List[_Scope]) -> None:
        if isinstance(node, IfStatement):
            self.expression(node.condition, stack)
            self.block(node.body, stack, 'if')
            for condition, body in node.elseifs:
                self.at_expression(condition)
                self.expression(condition, stack)
                self.block(body, stack, 'if')
            self.block(node.else_body, stack, 'if')
        elif isinstance(node, ForLoop):
            self.expression([node.from_val, node.to_val, node.step], stack)
            self.at(node)
            if _literal_of(node.from_val, 'int') and _literal_of(node.step, 'float'):
                self.report(REFUSE, 'for-step-type', node.var, FOR_STEP_TYPE_MESSAGE.format(node.var))
            self.block(node.body, stack, 'for', [node.var], LOOP_COUNTER)
        elif isinstance(node, ForInLoop):
            self.expression(node.iterable, stack)
            self.block(node.body, stack, 'for', node.vars, LOOP_COUNTER)
        else:
            self.expression(node.condition, stack)
            self.block(node.body, stack, 'while')

    def function(self, node: FuncDecl, stack: List[_Scope]) -> None:
        if len(stack) > 1:
            self.report(REFUSE, 'nested-function', node.name, f"function '{node.name}' is declared inside "
                        f'{SCOPE_KIND_TEXT[stack[-1].kind]}; TradingView allows a function declaration only '
                        f'at global scope')
        self.expression([parameter.default for parameter in node.params], stack)
        self.block(node.body, stack, 'function', [parameter.name for parameter in node.params], PARAMETER,
                   {parameter.name: declared_type(parameter) for parameter in node.params})

    def reassignment(self, target: str, stack: List[_Scope]) -> None:
        if '.' in target:  # a field: `p.v := x` is valid anywhere
            return
        depth = self.depth_of(stack, target)
        functions = [index for index, scope in enumerate(stack) if scope.kind == 'function']
        if depth is None:
            if self.out_of_scope(stack, target):
                self.report(REFUSE, 'out-of-scope', target, UNDECLARED_MESSAGE.format(target))
            elif functions and target in self.global_names:
                self.report(REFUSE, 'global-modified-in-function', target,
                            f"a function cannot modify the global variable '{target}'")
            else:
                self.report(REFUSE, 'reassigned-undeclared', target, f"'{target}' is not declared before "
                            f"this ':='; TradingView refuses a reassignment of an undeclared variable")
        elif functions and depth < functions[-1]:
            self.report(REFUSE, 'global-modified-in-function', target,
                        f"a function cannot modify the {'global' if depth == 0 else 'enclosing'} variable '{target}'")
        elif stack[depth].names.get(target) == PARAMETER:
            self.report(REFUSE, 'parameter-modified', target, f"a function cannot modify its parameter '{target}'")

    def switch(self, node, stack: List[_Scope]) -> None:
        self.expression(node.expr, stack)
        for case, body in node.cases:
            self.at_expression(case)
            self.expression(case, stack)
            self.block(body, stack, 'switch')
        self.block(node.default, stack, 'switch')

    # ------------------------------------------------------------ expressions

    def expression(self, node, stack: List[_Scope]) -> None:
        if node is None or isinstance(node, (str, int, float, bool)):
            return
        if isinstance(node, (list, tuple)):
            for item in node:
                self.expression(item, stack)
        elif isinstance(node, dict):
            self.expression(list(node.values()), stack)
        elif isinstance(node, Identifier):
            if '.' not in node.name:  # `N.m` names a namespace, a type or a library unless N is in scope
                self.read(stack, node)
        elif isinstance(node, IndexAccess):
            if isinstance(node.object, IndexAccess):
                self.report(REFUSE, 'double-history', '', 'the [] history operator can be used only once on '
                            'the same value (close[1][2])', node)
            elif self.version >= FIELD_HISTORY_REFUSED_FROM_VERSION and self.field_read_rule.is_field_read(
                    node.object, lambda name: self.binding_in_scope(name, stack)):
                self.report(REFUSE, 'history-on-udt-field', '', self.field_history_message(node), node)
            elif self.version >= LOOP_COUNTER_HISTORY_REFUSED_FROM_VERSION and \
                    (counter := self.loop_counter_in(node.object, stack)) is not None:
                self.report(REFUSE, 'loop-counter-history', counter.name,
                            f'Variable "{counter.name}" doesn\'t have history values', counter)
            self.expression([node.object, node.index], stack)
        elif isinstance(node, FunctionCall):
            if not isinstance(node.func, str):
                self.expression(node.func, stack)
            self.expression([node.args, list(node.kwargs.values())], stack)
            self.na_of_a_bool(node, stack)
        elif isinstance(node, MethodCall):
            self.member_of_history(node, node.method)
            self.expression([node.object, node.args, list(node.kwargs.values())], stack)
        elif isinstance(node, MemberAccess):
            self.member_of_history(node, node.member)
            if not isinstance(node.object, str):
                self.expression(node.object, stack)
        elif isinstance(node, IfExpression):
            self.expression(node.condition, stack)
            self.block(node.true_expr, stack, 'if')
            self.block(node.false_expr, stack, 'if')
            if not node.chained:
                self.na_block_of_a_bool(node, stack)
        elif isinstance(node, TernaryOp):
            self.expression([node.condition, node.true_expr, node.false_expr], stack)
            self.na_arm_of_a_bool(node, stack)
        elif isinstance(node, SwitchExpression):
            self.switch(node, stack)
            self.na_block_of_a_bool(node, stack)
        elif isinstance(node, (BinaryOp, UnaryOp)):
            operands = [node.operand] if isinstance(node, UnaryOp) else [node.left, node.right]
            for operand in operands:
                if isinstance(operand, SwitchExpression) and not getattr(node, 'compound', False):
                    self.report(REFUSE, 'switch-operand', 'switch', SWITCH_OPERAND_MESSAGE, operand)
            self.expression(operands, stack)
        elif isinstance(node, STATEMENT_TYPES):
            self.statement(node, stack)
        elif dataclasses.is_dataclass(node):
            self.expression([getattr(node, field.name) for field in dataclasses.fields(node)
                             if field.name not in ('line', 'column')], stack)

    # ------------------------------------------------------------ Pine v6: a bool is never na

    def na_of_a_bool(self, call: FunctionCall, stack: List[_Scope]) -> None:
        """`na(b)`, `nz(b)`, `fixnan(b)` of a value known to be a bool, refused from Pine v6."""
        if self.version < BOOL_NEVER_NA_FROM_VERSION:
            return
        name = 'na' if isinstance(call.func, NaLiteral) else call.func
        if name not in ('na', 'nz', 'fixnan'):
            return
        argument = call.args[0] if call.args else call.kwargs.get('source', call.kwargs.get('x'))
        if argument is None or not self.is_bool(argument, stack):
            return
        message = (f'na() of a bool: {BOOL_NEVER_NA_MESSAGE}' if name == 'na' else
                   f'{name}() takes a number, not a bool: {BOOL_NEVER_NA_MESSAGE}')
        self.report(REFUSE, 'bool-never-na', name, message, _positioned(argument))

    def na_arm_of_a_bool(self, node: TernaryOp, stack: List[_Scope]) -> None:
        """`c ? b : na` or `c ? na : b` with `b` known to be a bool, refused from Pine v6: MEASURED on TradingView
        2026-11-13, `x = c ? close > open : na` gives `Cannot call "operator ?:" with argument "expr2"="na". An
        argument of "simple na" type was used but a "series bool" is expected. (CE10123)`; `c ? true : na` the same
        with "simple bool", `c ? na : close > open` with "expr1"."""
        if self.version < BOOL_NEVER_NA_FROM_VERSION:
            return
        for slot, arm, other in (('expr1', node.true_expr, node.false_expr), ('expr2', node.false_expr, node.true_expr)):
            if _is_na(arm) and not _is_na(other) and self.is_bool(other, stack):
                self.report(REFUSE, 'bool-never-na', slot,
                            f'Cannot call "operator ?:" with argument "{slot}"="na". An argument of "simple na" type '
                            f'was used but a bool is expected (CE10123): {BOOL_NEVER_NA_MESSAGE}', _positioned(arm))

    def na_block_of_a_bool(self, node, stack: List[_Scope]) -> None:
        """An if/switch value with a bool arm and an `na` arm, refused from Pine v6: MEASURED on TradingView
        2026-11-14, `b = if c1` + `flag` + `else if c2` + `na` gives `Return type of one of the "if" or "switch"
        blocks is not compatible with return type of other block(s) (series bool; simple na)`."""
        if self.version < BOOL_NEVER_NA_FROM_VERSION:
            return
        tails = list(value_tails(node))
        na_tail = next((tail for tail in tails if _is_na(tail)), None)
        if na_tail is not None and any(not _is_na(tail) and self.is_bool(tail, stack) for tail in tails):
            self.report(REFUSE, 'bool-never-na', 'if', NA_BLOCK_OF_A_BOOL_MESSAGE, _positioned(na_tail))

    def bool_declared_na(self, node) -> None:
        """`bool b = na` (`var` and `varip` too), refused from Pine v6."""
        hint = getattr(node, 'type_hint', None)
        if self.version >= BOOL_NEVER_NA_FROM_VERSION and hint and hint.split()[-1] == 'bool' \
                and _is_na(node.value):
            name = node.name if isinstance(node, (VarDecl, VaripDecl)) else node.target
            self.report(REFUSE, 'bool-never-na', name, f"'{name}' is declared a bool and na: {BOOL_NEVER_NA_MESSAGE}")

    def bool_reassigned_na(self, node: Reassignment, stack: List[_Scope]) -> None:
        """`b := na` of a name known to hold a bool, refused from Pine v6."""
        if self.version >= BOOL_NEVER_NA_FROM_VERSION and '.' not in node.target and _is_na(node.value) \
                and self.is_bool(Identifier(name=node.target), stack):
            self.report(REFUSE, 'bool-never-na', node.target,
                        f"'{node.target}' holds a bool and cannot be assigned na: {BOOL_NEVER_NA_MESSAGE}")

    def is_bool(self, expression, stack: List[_Scope]) -> bool:
        """`expression` is known to be a bool here (BOOL_NEVER_NA_FROM_VERSION); False when not known."""
        def named(name: str) -> bool:
            depth = self.depth_of(stack, name)
            return depth is not None and name in stack[depth].bools

        def bound(name: str) -> bool:
            return self.depth_of(stack, name) is not None or name in self.global_names \
                or name in self.local_only or name in self.function_names or name in self.type_names
        return _is_bool(expression, named, self.bool_functions, bound)

    def functions_of_bool_value(self) -> set:
        """The functions declared once whose value is known to be a bool: their last expression is one, read
        with their typed bool parameters and the names their body declares from one, in declaration order."""
        found: set = set()
        declared = self.global_names | self.local_only | self.function_names | self.type_names

        def bound(name: str) -> bool:
            return name in declared
        for item in self.top_items:
            if not isinstance(item, FuncDecl) or item.is_method or item.name in self.overloaded:
                continue
            names = {parameter.name for parameter in item.params if declared_type(parameter) == 'bool'}
            body = item.body if isinstance(item.body, list) else [ExpressionStatement(expr=item.body)]
            for statement in body[:-1]:
                if isinstance(statement, (VarDecl, VaripDecl, Assignment)) and isinstance(
                        getattr(statement, 'target', ''), str) and (
                        declared_type(statement) == 'bool'
                        or _is_bool(statement.value, names.__contains__, found, bound)):
                    names.add(statement.name if isinstance(statement, (VarDecl, VaripDecl)) else statement.target)
            last = body[-1] if body else None
            if isinstance(last, ExpressionStatement) and _is_bool(last.expr, names.__contains__, found, bound):
                found.add(item.name)
        return found

    def tuple_width(self, value, seen: frozenset = frozenset()) -> Optional[int]:
        """How many values `value` gives a tuple declaration, when that is known: a tuple literal (the third argument
        of `request.security`), a call of a function declared once whose last expression is a tuple or such a
        call, or a `request.security` of one of these; None otherwise."""
        if isinstance(value, ArrayLiteral):
            return len(value.elements)
        if not isinstance(value, FunctionCall) or not isinstance(value.func, str):
            return None
        if value.func in SECURITY_FUNCTIONS:
            expression = value.args[2] if len(value.args) > 2 else value.kwargs.get('expression')
            return self.tuple_width(expression, seen) if expression is not None else None
        declaration = self.single_functions.get(value.func)
        if declaration is None or value.func in seen:
            return None
        body = declaration.body if isinstance(declaration.body, list) else [ExpressionStatement(expr=declaration.body)]
        last = body[-1] if body else None
        if not isinstance(last, ExpressionStatement) or not isinstance(last.expr, (ArrayLiteral, FunctionCall)) \
                or (isinstance(last.expr, FunctionCall) and last.expr.func in SECURITY_FUNCTIONS):
            return None
        return self.tuple_width(last.expr, seen | {value.func})

    def is_loop_counter(self, node, stack: List[_Scope]) -> bool:
        """`node` reads the counter of a `for i = a to b` loop that is open here: the innermost binding of
        its name is the counter, so a name a nested block declares again is that declaration's, not the counter's.
        A name the loop body declares again at the counter's own level keeps the counter's binding (a scope's
        first declaration wins) and is refused: UNMEASURED on TradingView, which refuses the redeclaration itself."""
        depth = self.depth_of(stack, node.name) if isinstance(node, Identifier) else None
        return depth is not None and stack[depth].names[node.name] == LOOP_COUNTER

    def loop_counter_in(self, node, stack: List[_Scope]) -> Optional[Identifier]:
        """The counter of an open `for` loop that `node` reads as an operand: the counter itself (`i[1]`) or
        an operand of an arithmetic expression (`(close * close * i)[1]` -- Pine v4, v5 and v6 refuse the history
        of either, `Variable 'i' doesn't have history values`). An argument of a call is not looked into: a
        function given the counter (`f(close * i)`, its body reading `x[1]`) compiles."""
        if isinstance(node, Identifier):
            return node if self.is_loop_counter(node, stack) else None
        if isinstance(node, BinaryOp):
            return self.loop_counter_in(node.left, stack) or self.loop_counter_in(node.right, stack)
        if isinstance(node, UnaryOp):
            return self.loop_counter_in(node.operand, stack)
        if isinstance(node, TernaryOp):
            return (self.loop_counter_in(node.condition, stack) or self.loop_counter_in(node.true_expr, stack)
                    or self.loop_counter_in(node.false_expr, stack))
        return None

    def binding_in_scope(self, name: str, stack: List[_Scope]) -> Optional[HeadBinding]:
        """The variable `name` names here, with its declared type: the binding in scope, or a
        global (declared above or further down, typed as the scope renamer types it, by its
        first global declaration); None when `name` is no variable here."""
        depth = self.depth_of(stack, name)
        if depth is not None and depth > 0:  # a global (depth 0) is typed below, in the renamer's order
            return HeadBinding(stack[depth].types.get(name))
        return HeadBinding(self.global_types.get(name)) if name in self.global_names else None

    def variable_type(self, name: str, stack: List[_Scope]) -> Optional[str]:
        """The type of the variable `name` names here (`binding_in_scope`), None when unknown."""
        binding = self.binding_in_scope(name, stack)
        return binding.type_name if binding else None

    @staticmethod
    def field_history_message(site: IndexAccess) -> str:
        """The advice indexes the object, then walks the field path: `o.i.v[1]` -> `(o[1]).i.v`
        (`(o.i[1]).v` would index a field again)."""
        index = site.index.value if isinstance(site.index, Literal) else 'n'
        spelled = site.object.name if isinstance(site.object, Identifier) else ''
        if isinstance(site.object, MemberAccess) and isinstance(site.object.object, str):
            spelled = f'{site.object.object}.{site.object.member}'
        head, _, path = spelled.partition('.')
        object_text, field_text = (head, path) if path else ('object', 'field')
        return (f"the [] history operator cannot be used on a field of a user-defined type from Pine v6; "
                f"write ({object_text}[{index}]).{field_text} for the field of the object {index} bar(s) back, "
                f"or assign the field to a variable and index that variable")

    # ------------------------------------------------------------ recursion

    def recursion(self) -> None:
        """A call that closes a cycle in the call graph of the script's functions,
        refused at the call. An overloaded name resolves by signature, so it is
        left out of the graph (expds_097 calls one overload from another); an
        overload that passes its own parameters, unchanged, to its own name
        resolves to itself and is refused."""
        declared = [item for item in self.top_items if isinstance(item, FuncDecl) and not item.is_method]
        # a call by a method's name may select the method (`f(P.new(x))` beside `method f(P this)`)
        method_names = {item.name for item in self.top_items if isinstance(item, FuncDecl) and item.is_method}
        single = {function.name: function for function in declared
                  if function.name not in self.overloaded and function.name not in method_names}
        calls = {name: [node for node in walk(function.body)
                        if isinstance(node, FunctionCall) and isinstance(node.func, str) and node.func in single]
                 for name, function in single.items()}
        callees = {name: {call.func for call in found} for name, found in calls.items()}
        for name, function in single.items():
            closing = next((call for call in calls[name]
                            if call.func == name or self.reaches(call.func, name, callees)), None)
            if closing is not None:
                self.report_recursion(name, closing)
        for function in declared:
            if function.name in self.overloaded:
                own = next((node for node in walk(function.body) if _passes_own_parameters(node, function)), None)
                if own is not None:
                    self.report_recursion(function.name, own)

    def report_recursion(self, name: str, call: FunctionCall) -> None:
        self.report(REFUSE, 'recursion', name, f"function '{name}' calls itself (directly or through another "
                    f'function); TradingView does not allow recursion', call)

    @staticmethod
    def reaches(start: str, goal: str, callees: Dict[str, set]) -> bool:
        seen, pending = set(), list(callees[start])
        while pending:
            name = pending.pop()
            if name == goal:
                return True
            if name not in seen:
                seen.add(name)
                pending.extend(callees.get(name, ()))
        return False


def _is_na(expression) -> bool:
    return isinstance(expression, NaLiteral) or (isinstance(expression, Identifier) and expression.name == 'na')


def _is_bool(expression, named, bool_functions, bound=lambda name: False) -> bool:
    """`expression` is known to be a bool; `named(name)` says whether a name holds one, `bound(name)` whether the
    script declares the name (then `session.ismarket` reads a field of it, not the builtin)."""
    def builtin(name: str) -> bool:
        return (name in BOOL_BUILTINS or name == 'input.bool') and not bound(name.partition('.')[0])
    if isinstance(expression, Literal):
        return expression.literal_type == 'bool'
    if isinstance(expression, Identifier):
        return expression.name in ('true', 'false') or builtin(expression.name) or named(expression.name)
    if isinstance(expression, BinaryOp):
        return expression.op in BOOL_OPERATORS
    if isinstance(expression, UnaryOp):
        return expression.op == 'not'
    if isinstance(expression, IndexAccess):
        return _is_bool(expression.object, named, bool_functions, bound)
    if isinstance(expression, TernaryOp):
        arms = [arm for arm in (expression.true_expr, expression.false_expr) if not _is_na(arm)]
        return bool(arms) and all(_is_bool(arm, named, bool_functions, bound) for arm in arms)
    if isinstance(expression, FunctionCall):
        if isinstance(expression.func, NaLiteral):
            return True
        return isinstance(expression.func, str) and (builtin(expression.func) or expression.func in bool_functions)
    return False


def _is_a_bool_input(node: InputDecl) -> bool:
    """`input.bool(...)`, or `input(true)` whose default is a bool literal."""
    default = node.args[0] if node.args else node.kwargs.get('defval')
    return input_type(node) == 'bool' or (
        node.func == 'input' and isinstance(default, Literal) and default.literal_type == 'bool')


def _positioned(node):
    """The part of `node` written first that has a position (a call written `na(...)` has none of its own, a
    history read `b[1]` has the position of its `[`)."""
    parts = [part for part in walk(node) if getattr(part, 'line', 0)]
    return min(parts, key=lambda part: (part.line, part.column)) if parts else None


def _names_declared_in(nodes: list) -> set:
    """Every name a declaration, loop or parameter in `nodes` binds."""
    names = {name for node in nodes for name in _declared_names(node)}
    for node in nodes:
        if isinstance(node, ForLoop):
            names.add(node.var)
        elif isinstance(node, ForInLoop):
            names.update(node.vars)
        elif isinstance(node, FuncDecl):
            names.update(parameter.name for parameter in node.params)
    return names


def _passes_own_parameters(node, function: FuncDecl) -> bool:
    """`f(x)` inside `f(float x)`: the call's arguments are the function's own
    parameters, in order and unchanged (no local of their names), so it
    selects this very overload."""
    if not (isinstance(node, FunctionCall) and node.func == function.name and not node.kwargs):
        return False
    parameters = [parameter.name for parameter in function.params]
    arguments = [argument.name if isinstance(argument, Identifier) else None for argument in node.args]
    redeclared = _names_declared_in(list(walk(function.body)))
    return arguments == parameters and not redeclared.intersection(parameters)
