"""Pine v4 and v5 divide two const ints as ints: `(9 - 1) / 2` is 4 and `9 / 2` is 4.

PyneComp prints such a division `cast_int(a / b)`. A const int, as it types one, is

* an int literal;
* a name declared without a type keyword (`x = 4`, `var x = 4`) from a const int, and never
  reassigned (`:=`, `+=`);
* a sign or a `+ - * / %` of const ints.

A name declared with a type (`int n = 4`, `const int K = 6`), an input, a parameter, a loop
counter, a tuple element and a builtin series (`bar_index`) are not const ints. Pine v6 divides
const ints as floats, so nothing is cast there.
"""
from __future__ import annotations

from typing import Dict, List, Set

from .ast_nodes import (
    Assignment, BinaryOp, ForInLoop, ForLoop, FuncDecl, Identifier, Literal, Reassignment, Script,
    TupleDestructure, UnaryOp, VarDecl, VaripDecl,
)
from .ast_walk import walk

_INT_OPERATORS = frozenset({'+', '-', '*', '/', '%'})


def is_const_int(expression, names: Set[str]) -> bool:
    """Whether `expression` is a const int, `names` being the const int names."""
    if isinstance(expression, Literal):
        return expression.literal_type == 'int'
    if isinstance(expression, Identifier):
        return expression.name in names
    if isinstance(expression, UnaryOp):
        return expression.op in ('-', '+') and is_const_int(expression.operand, names)
    if isinstance(expression, BinaryOp):
        return (expression.op in _INT_OPERATORS and is_const_int(expression.left, names)
                and is_const_int(expression.right, names))
    return False


def const_int_names(script: Script) -> Set[str]:
    """The names of `script` that hold a const int (see the module docstring)."""
    declared: Dict[str, List] = {}
    excluded: Set[str] = set()
    for node in walk(script):
        if isinstance(node, Assignment) and isinstance(node.target, str):
            if node.type_hint or node.is_const:
                excluded.add(node.target)
            else:
                declared.setdefault(node.target, []).append(node.value)
        elif isinstance(node, (VarDecl, VaripDecl)):
            if node.type_hint:
                excluded.add(node.name)
            else:
                declared.setdefault(node.name, []).append(node.value)
        elif isinstance(node, Reassignment):
            excluded.add(node.target)
        elif isinstance(node, TupleDestructure):
            excluded.update(node.names)
        elif isinstance(node, ForLoop):
            excluded.add(node.var)
        elif isinstance(node, ForInLoop):
            excluded.update(node.vars)
        elif isinstance(node, FuncDecl):
            excluded.update(parameter.name for parameter in node.params)
    candidates = {name: values for name, values in declared.items() if name not in excluded}
    names: Set[str] = set()
    changed = True
    while changed:
        changed = False
        for name, values in candidates.items():
            if name not in names and all(is_const_int(value, names) for value in values):
                names.add(name)
                changed = True
    return names
